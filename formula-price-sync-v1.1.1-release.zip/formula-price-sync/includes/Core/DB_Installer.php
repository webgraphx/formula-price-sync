<?php
/**
 * Database installer and schema management.
 *
 * @package FormulaPriceSync
 */

namespace FormulaPriceSync\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class DB_Installer
 *
 * Handles creation and maintenance of custom database tables.
 */
class DB_Installer {

	/**
	 * Database schema version.
	 *
	 * @var string
	 */
	const DB_VERSION = '1.0.0';

	/**
	 * Option key for stored DB version.
	 *
	 * @var string
	 */
	const DB_VERSION_OPTION = 'fps_db_version';

	/**
	 * Run on plugin activation.
	 *
	 * Creates the custom price logs table and stores the schema version.
	 *
	 * @return void
	 */
	public static function install() {
		self::create_tables();
		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
		// Auto-start 30-day trial for testing.
		if ( ! get_option( \FormulaPriceSync\Licensing\Zhaket_Guard::STATUS_OPTION ) || 'valid' !== get_option( \FormulaPriceSync\Licensing\Zhaket_Guard::STATUS_OPTION ) ) {
			\FormulaPriceSync\Licensing\Zhaket_Guard::start_trial();
		}

		// Ensure Action Scheduler tables exist if the library is available.
		if ( function_exists( 'action_scheduler_register_post_type' ) ) {
			// Action Scheduler is already bootstrapped by WooCommerce in most installs.
		}
	}

	/**
	 * Run on plugin deactivation.
	 *
	 * Currently does not drop tables to preserve audit history.
	 *
	 * @return void
	 */
	public static function deactivate() {
		// Intentionally left empty – we keep the logs table for historical data.
		// Scheduled actions will be cleaned by Action Scheduler itself.
	}

	/**
	 * Create or update the custom tables using dbDelta.
	 *
	 * @return void
	 */
	public static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$table_name      = $wpdb->prefix . 'fps_price_logs';

		$sql = "CREATE TABLE {$table_name} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id BIGINT(20) UNSIGNED NOT NULL,
			variation_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			old_price DECIMAL(15,2) NOT NULL DEFAULT 0.00,
			new_price DECIMAL(15,2) NOT NULL DEFAULT 0.00,
			source_rate DECIMAL(15,2) NOT NULL DEFAULT 0.00,
			trigger_type VARCHAR(20) NOT NULL DEFAULT 'scheduled',
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY product_id (product_id),
			KEY variation_id (variation_id),
			KEY created_at (created_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Maybe upgrade the database schema if version differs.
	 *
	 * Can be called on plugins_loaded or admin_init in later phases.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		$installed = get_option( self::DB_VERSION_OPTION, '0' );

		if ( version_compare( $installed, self::DB_VERSION, '<' ) ) {
			self::create_tables();
			update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
		}
	}

	/**
	 * Drop the custom table (used only for complete uninstall).
	 *
	 * @return void
	 */
	public static function drop_tables() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'fps_price_logs';
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "DROP TABLE IF EXISTS {$table_name}" );

		delete_option( self::DB_VERSION_OPTION );
	}
}
