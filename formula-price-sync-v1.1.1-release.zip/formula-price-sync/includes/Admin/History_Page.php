<?php
/**
 * Historical rates / sync history dashboard tab.
 *
 * @package FormulaPriceSync
 */

namespace FormulaPriceSync\Admin;

use FormulaPriceSync\API\API_Manager;
use FormulaPriceSync\API\Circuit_Breaker;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class History_Page
 *
 * Shows last accepted rates and recent sync summary.
 */
class History_Page {

	/**
	 * Render history view.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'formula-price-sync' ) );
		}

		$last_rates = get_option( Circuit_Breaker::LAST_ACCEPTED_OPTION, array() );
		if ( ! is_array( $last_rates ) ) {
			$last_rates = array();
		}

		$api    = new API_Manager();
		$cached = $api->get_rates();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'تاریخچه نرخ و همگام‌سازی', 'formula-price-sync' ); ?></h1>

			<div class="fps-grid" style="margin-top:16px;">
				<div class="fps-card">
					<h2><?php esc_html_e( 'آخرین نرخ پذیرفته‌شده (Circuit Breaker)', 'formula-price-sync' ); ?></h2>
					<?php self::render_rate_list( $last_rates ); ?>
				</div>
				<div class="fps-card">
					<h2><?php esc_html_e( 'نرخ فعلی کش‌شده', 'formula-price-sync' ); ?></h2>
					<?php self::render_rate_list( $cached ); ?>
				</div>
			</div>

			<p class="description" style="margin-top:16px;">
				<?php esc_html_e( 'برای مشاهده تغییرات قیمت محصولات به منوی «تاریخچه قیمت» مراجعه کنید.', 'formula-price-sync' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * @param array $rates Rates.
	 * @return void
	 */
	private static function render_rate_list( array $rates ): void {
		if ( empty( $rates ) ) {
			echo '<p class="fps-muted">' . esc_html__( 'داده‌ای موجود نیست.', 'formula-price-sync' ) . '</p>';
			return;
		}
		$labels = array(
			'usd'       => 'USD',
			'eur'       => 'EUR',
			'gold_18k'  => __( 'طلا ۱۸', 'formula-price-sync' ),
			'gold_24k'  => __( 'طلا ۲۴', 'formula-price-sync' ),
			'coin'      => __( 'سکه', 'formula-price-sync' ),
			'source'    => __( 'منبع', 'formula-price-sync' ),
			'timestamp' => __( 'زمان', 'formula-price-sync' ),
		);
		echo '<table class="widefat striped"><tbody>';
		foreach ( $labels as $key => $label ) {
			if ( ! isset( $rates[ $key ] ) ) {
				continue;
			}
			$val = $rates[ $key ];
			if ( 'timestamp' === $key && is_numeric( $val ) ) {
				$val = date_i18n( 'Y/m/d H:i', (int) $val );
			} elseif ( is_numeric( $val ) && 'source' !== $key ) {
				$val = number_format_i18n( (float) $val, 0 );
			}
			echo '<tr><th>' . esc_html( $label ) . '</th><td>' . esc_html( (string) $val ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}
}
