<?php
/**
 * Plugin settings via WordPress Settings API.
 *
 * @package FormulaPriceSync
 */

namespace FormulaPriceSync\Admin;

use FormulaPriceSync\Engine\Rounding;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Settings_API
 */
class Settings_API {

	/**
	 * Option group.
	 *
	 * @var string
	 */
	const OPTION_GROUP = 'fps_settings';

	/**
	 * Option name.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'fps_options';

	/**
	 * Initialize.
	 *
	 * @return void
	 */
	public static function init(): void {
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Register settings, sections and fields.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		register_setting(
			self::OPTION_GROUP,
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);

		add_settings_section(
			'fps_api_section',
			__( 'تنظیمات API و همگام‌سازی', 'formula-price-sync' ),
			'__return_false',
			'fps-settings'
		);

		add_settings_field(
			'fps_update_interval',
			__( 'بازه به‌روزرسانی (دقیقه)', 'formula-price-sync' ),
			array( __CLASS__, 'render_interval_field' ),
			'fps-settings',
			'fps_api_section'
		);

		add_settings_field(
			'fps_default_rounding',
			__( 'قانون رند پیش‌فرض', 'formula-price-sync' ),
			array( __CLASS__, 'render_rounding_field' ),
			'fps-settings',
			'fps_api_section'
		);

		add_settings_field(
			'fps_navasan_api_key',
			__( 'کلید API ناوسان (اختیاری)', 'formula-price-sync' ),
			array( __CLASS__, 'render_navasan_key_field' ),
			'fps-settings',
			'fps_api_section'
		);

		add_settings_field(
			'fps_rate_divisor',
			__( 'تبدیل واحد نرخ API', 'formula-price-sync' ),
			array( __CLASS__, 'render_rate_divisor_field' ),
			'fps-settings',
			'fps_api_section'
		);

		add_settings_field(
			'fps_manual_rates',
			__( 'نرخ‌های دستی (fallback)', 'formula-price-sync' ),
			array( __CLASS__, 'render_manual_rates_field' ),
			'fps-settings',
			'fps_api_section'
		);
	}

	/**
	 * Default options.
	 *
	 * @return array
	 */
	public static function defaults(): array {
		return array(
			'update_interval'   => 20,
			'default_rounding'  => 'none',
			'navasan_api_key'   => '',
			'rate_divisor'      => 1,
			'manual_rates'      => '',
		);
	}

	/**
	 * Get a single option value.
	 *
	 * @param string $key     Option key.
	 * @param mixed  $default Default.
	 * @return mixed
	 */
	public static function get( string $key, $default = null ) {
		$opts = get_option( self::OPTION_NAME, self::defaults() );
		if ( ! is_array( $opts ) ) {
			$opts = self::defaults();
		}
		return array_key_exists( $key, $opts ) ? $opts[ $key ] : $default;
	}

	/**
	 * Sanitize settings input.
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ): array {
		$input = is_array( $input ) ? $input : array();
		$out   = self::defaults();

		$interval = isset( $input['update_interval'] ) ? absint( $input['update_interval'] ) : 20;
		if ( ! in_array( $interval, array( 15, 20, 30, 60 ), true ) ) {
			$interval = 20;
		}
		$out['update_interval'] = $interval;

		$rounding = isset( $input['default_rounding'] ) ? sanitize_key( $input['default_rounding'] ) : 'none';
		$out['default_rounding'] = Rounding::is_valid_rule( $rounding ) ? $rounding : 'none';

		$out['navasan_api_key'] = isset( $input['navasan_api_key'] )
			? sanitize_text_field( $input['navasan_api_key'] )
			: '';

		$div = isset( $input['rate_divisor'] ) ? absint( $input['rate_divisor'] ) : 1;
		$out['rate_divisor'] = in_array( $div, array( 1, 10 ), true ) ? $div : 1;

		// Sync to legacy option used by Navasan provider.
		if ( ! empty( $out['navasan_api_key'] ) ) {
			update_option( 'fps_navasan_api_key', $out['navasan_api_key'], false );
		}

		$manual_raw = isset( $input['manual_rates'] ) ? sanitize_textarea_field( $input['manual_rates'] ) : '';
		$out['manual_rates'] = $manual_raw;

		// Parse and store structured manual rates for Manual provider.
		$parsed = self::parse_manual_rates( $manual_raw );
		if ( ! empty( $parsed ) ) {
			\FormulaPriceSync\API\Providers\Manual::save_rates( $parsed );
		}

		return $out;
	}

	/**
	 * Parse manual rates textarea (key=value lines).
	 *
	 * @param string $raw Raw text.
	 * @return array
	 */
	private static function parse_manual_rates( string $raw ): array {
		$out  = array();
		$lines = preg_split( '/\r\n|\r|\n/', $raw );
		if ( ! is_array( $lines ) ) {
			return $out;
		}
		$allowed = array( 'usd', 'eur', 'gold_18k', 'gold_24k', 'coin' );
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '=' ) ) {
				continue;
			}
			list( $k, $v ) = array_map( 'trim', explode( '=', $line, 2 ) );
			$k = sanitize_key( $k );
			if ( ! in_array( $k, $allowed, true ) ) {
				continue;
			}
			$val = (float) $v;
			if ( is_finite( $val ) && $val > 0 ) {
				$out[ $k ] = $val;
			}
		}
		return $out;
	}

	/**
	 * Render update interval field.
	 *
	 * @return void
	 */
	public static function render_interval_field(): void {
		$val = (int) self::get( 'update_interval', 20 );
		?>
		<select name="<?php echo esc_attr( self::OPTION_NAME ); ?>[update_interval]">
			<?php foreach ( array( 15, 20, 30, 60 ) as $m ) : ?>
				<option value="<?php echo esc_attr( (string) $m ); ?>" <?php selected( $val, $m ); ?>>
					<?php echo esc_html( (string) $m ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<p class="description"><?php esc_html_e( 'بازه کش نرخ‌ها (دقیقه).', 'formula-price-sync' ); ?></p>
		<?php
	}

	/**
	 * Render default rounding field.
	 *
	 * @return void
	 */
	public static function render_rounding_field(): void {
		$val    = self::get( 'default_rounding', 'none' );
		$labels = Rounding::get_rule_labels();
		?>
		<select name="<?php echo esc_attr( self::OPTION_NAME ); ?>[default_rounding]">
			<?php foreach ( $labels as $key => $label ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $val, $key ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	/**
	 * Render Navasan API key field.
	 *
	 * @return void
	 */
	public static function render_navasan_key_field(): void {
		$val = (string) self::get( 'navasan_api_key', '' );
		?>
		<input type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[navasan_api_key]" value="<?php echo esc_attr( $val ); ?>" />
		<?php
	}

	/**
	 * Rate unit conversion field.
	 *
	 * @return void
	 */
	public static function render_rate_divisor_field(): void {
		$val = (int) self::get( 'rate_divisor', 1 );
		?>
		<select name="<?php echo esc_attr( self::OPTION_NAME ); ?>[rate_divisor]">
			<option value="1" <?php selected( $val, 1 ); ?>><?php esc_html_e( 'ریال (بدون تبدیل — نرخ API به ریال)', 'formula-price-sync' ); ?></option>
			<option value="10" <?php selected( $val, 10 ); ?>><?php esc_html_e( 'تومان (تقسیم بر ۱۰ — تبدیل ریال API به تومان)', 'formula-price-sync' ); ?></option>
		</select>
		<p class="description">
			<?php esc_html_e( 'پیش‌فرض: ریال (مطابق خروجی API). اگر فروشگاه شما به تومان قیمت می‌گذارد، «تومان» را انتخاب کنید تا نرخ‌ها بر ۱۰ تقسیم شوند.', 'formula-price-sync' ); ?>
		</p>
		<?php
	}

	/**
	 * Render manual rates textarea.
	 *
	 * @return void
	 */
	public static function render_manual_rates_field(): void {
		$val = (string) self::get( 'manual_rates', '' );
		?>
		<textarea name="<?php echo esc_attr( self::OPTION_NAME ); ?>[manual_rates]" rows="6" class="large-text code" placeholder="usd=60000&#10;gold_18k=3500000&#10;coin=40000000"><?php echo esc_textarea( $val ); ?></textarea>
		<p class="description"><?php esc_html_e( 'هر خط: key=value — کلیدهای مجاز: usd, eur, gold_18k, gold_24k, coin', 'formula-price-sync' ); ?></p>
		<?php
	}

	/**
	 * Render settings form (called from Admin_Menu).
	 *
	 * @return void
	 */
	public static function render_settings_form(): void {
		?>
		<form method="post" action="options.php">
			<?php
			settings_fields( self::OPTION_GROUP );
			do_settings_sections( 'fps-settings' );
			submit_button( __( 'ذخیره تنظیمات', 'formula-price-sync' ) );
			?>
		</form>
		<?php
	}
}
