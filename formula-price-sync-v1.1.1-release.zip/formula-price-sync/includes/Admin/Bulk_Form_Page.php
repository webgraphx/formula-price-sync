<?php
/**
 * Bulk price sync form page.
 *
 * @package FormulaPriceSync
 */

namespace FormulaPriceSync\Admin;

use FormulaPriceSync\Licensing\Zhaket_Guard;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Bulk_Form_Page
 */
class Bulk_Form_Page {

	/**
	 * Render bulk sync UI.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'formula-price-sync' ) );
		}

		$license_ok = ! Zhaket_Guard::should_block();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'همگام‌سازی دسته‌ای قیمت‌ها', 'formula-price-sync' ); ?></h1>

			<?php if ( ! $license_ok ) : ?>
				<div class="notice notice-warning"><p><?php esc_html_e( 'برای همگام‌سازی، ابتدا لایسنس را فعال کنید.', 'formula-price-sync' ); ?></p></div>
			<?php endif; ?>

			<div class="fps-card" style="max-width:640px;margin-top:16px;">
				<p><?php esc_html_e( 'این عملیات نرخ‌های زنده را دریافت کرده و قیمت تمام محصولات/ورییشن‌های دارای «قیمت‌گذاری خودکار» را در پس‌زمینه (چانک‌های ۵۰تایی) به‌روزرسانی می‌کند.', 'formula-price-sync' ); ?></p>

				<p>
					<button type="button" class="button button-primary" id="fps-bulk-sync-btn" <?php disabled( ! $license_ok ); ?>>
						<?php esc_html_e( 'شروع همگام‌سازی دسته‌ای', 'formula-price-sync' ); ?>
					</button>
					<span class="spinner" id="fps-bulk-spinner" style="float:none;margin:0 8px;"></span>
				</p>

				<div id="fps-bulk-progress" style="display:none;margin-top:12px;">
					<div style="background:#f0f0f1;border-radius:4px;height:12px;overflow:hidden;">
						<div id="fps-bulk-bar" style="background:#2271b1;height:100%;width:0%;transition:width .3s;"></div>
					</div>
					<p id="fps-bulk-status" class="description"></p>
				</div>

				<div id="fps-bulk-result" class="notice" style="display:none;margin-top:12px;"></div>
			</div>
		</div>
		<?php
	}
}
