/**
 * Formula Price Sync – Admin JS
 * Dynamic gold vs currency fields + live Rial preview + bulk sync.
 */
(function ($) {
	'use strict';

	function parseNum(sel) {
		var v = parseFloat($(sel).val());
		return isFinite(v) && v >= 0 ? v : 0;
	}

	function formatMoney(n) {
		try {
			return new Intl.NumberFormat('fa-IR').format(Math.round(n)) + ' ریال';
		} catch (e) {
			return Math.round(n).toLocaleString() + ' ریال';
		}
	}

	function i18n(key, fallback) {
		if (typeof FPS !== 'undefined' && FPS.i18n && FPS.i18n[key]) {
			return FPS.i18n[key];
		}
		return fallback || '';
	}

	function getRateForSource() {
		var $el = $('#fps-current-rate');
		if (!$el.length) {
			return 0;
		}
		var source = $('#_fps_source_type').val() || 'gold_18k';
		var key = source;
		if (source === 'currency') {
			key = $('#_fps_currency_code').val() || 'usd';
		} else if (source === 'custom_formula') {
			key = 'gold_18k';
		}
		var r = parseFloat($el.data(key));
		if (!isFinite(r) || r <= 0) {
			r = parseFloat($el.data('rate'));
		}
		return isFinite(r) && r > 0 ? r : 0;
	}

	function updateBaseFieldLabel() {
		var source = $('#_fps_source_type').val() || 'gold_18k';
		var $row = $('#_fps_base_foreign_price').closest('.form-field, .fps-base-amount-row');
		var $label = $row.find('label');
		var $desc = $row.find('.description');
		var currency = $('#_fps_currency_code').val() || 'usd';
		var currencyLabel = currency === 'eur' ? 'یورو' : 'دلار';

		if (source === 'currency') {
			$label.html(i18n('base_price_label', 'قیمت پایه ارزی') + ' (' + currencyLabel + ')');
			if ($desc.length) {
				$desc.text(i18n('base_price_desc', 'قیمت کالا به واحد ارز (مثلاً ۷۰۰ دلار برای گوشی).'));
			}
			$('#_fps_base_foreign_price').attr('placeholder', currency === 'eur' ? 'مثلاً 749' : 'مثلاً 700');
		} else if (source === 'custom_formula') {
			$label.html(i18n('base_custom_label', 'مقدار پایه / وزن'));
			if ($desc.length) {
				$desc.text(i18n('base_custom_desc', 'مقدار {weight} در فرمول سفارشی.'));
			}
		} else {
			$label.html(i18n('weight_label', 'وزن (گرم)'));
			if ($desc.length) {
				$desc.text(i18n('weight_desc', 'وزن قطعه به گرم.'));
			}
			$('#_fps_base_foreign_price').attr('placeholder', 'مثلاً 10');
		}

		var $profitRow = $('#_fps_profit_percent').closest('.form-field, .fps-profit-field');
		var $profitLabel = $profitRow.find('label');
		if ($profitLabel.length) {
			if (source === 'currency') {
				$profitLabel.html(i18n('profit_currency', 'درصد سود روی قیمت تبدیل‌شده'));
			} else {
				$profitLabel.html(i18n('profit_gold', 'درصد سود فروشنده'));
			}
		}
	}

	function updateFormulaHint() {
		var source = $('#_fps_source_type').val() || 'gold_18k';
		var $hint = $('#fps-formula-hint');
		if (!$hint.length) {
			return;
		}
		var text = '';
		if (source === 'currency') {
			text = i18n('formula_currency', 'فرمول ارز: قیمت ریالی = قیمت پایه × نرخ ارز | نهایی = قیمت ریالی × (۱ + ٪سود) + هزینه ثابت');
		} else if (source === 'custom_formula') {
			text = i18n('formula_custom', 'فرمول سفارشی با متغیرهای مجاز اجرا می‌شود.');
		} else {
			text = i18n('formula_gold', 'فرمول طلا: ارزش خام = وزن × نرخ | اجرت | سود | مالیات فقط روی (اجرت+سود) | جمع نهایی');
		}
		$hint.text(text);
	}

	function calculatePreview() {
		var $preview = $('#fps-price-preview');
		if (!$preview.length) {
			return;
		}

		var sourceType = $('#_fps_source_type').val() || 'gold_18k';
		var baseAmount = parseNum('#_fps_base_foreign_price');
		var wage = parseNum('#_fps_wage_percent');
		var profit = parseNum('#_fps_profit_percent');
		var tax = parseNum('#_fps_tax_percent');
		if (tax <= 0) {
			tax = 9;
		}
		var fixedFee = parseNum('#_fps_fixed_fee');
		var rate = getRateForSource();

		if (baseAmount <= 0 || rate <= 0) {
			$preview.text('—');
			return;
		}

		var total = 0;
		if (sourceType === 'currency') {
			var baseRial = baseAmount * rate;
			total = baseRial * (1 + profit / 100) + fixedFee;
		} else if (sourceType === 'custom_formula') {
			total = baseAmount * rate + fixedFee;
		} else {
			var rawGold = baseAmount * rate;
			var wageAmt = rawGold * (wage / 100);
			var profitAmt = (rawGold + wageAmt) * (profit / 100);
			var taxAmt = (wageAmt + profitAmt) * (tax / 100);
			total = rawGold + wageAmt + profitAmt + taxAmt + fixedFee;
		}

		if (!isFinite(total) || total < 0) {
			$preview.text('—');
			return;
		}
		$preview.text(formatMoney(total));
	}

	function toggleFieldsBySource() {
		var source = $('#_fps_source_type').val() || 'gold_18k';
		var $wrap = $('.fps-pricing-fields');
		$wrap.removeClass('fps-source-currency fps-source-gold fps-source-custom');

		if (source === 'currency') {
			$wrap.addClass('fps-source-currency');
			$('.fps-pricing-fields .fps-currency-code-row').show();
			$('.fps-pricing-fields .fps-gold-only-field').hide();
			$('.fps-pricing-fields .fps-custom-formula-row').hide();
		} else if (source === 'custom_formula') {
			$wrap.addClass('fps-source-custom');
			$('.fps-pricing-fields .fps-currency-code-row').hide();
			$('.fps-pricing-fields .fps-gold-only-field').show();
			$('.fps-pricing-fields .fps-custom-formula-row').show();
		} else {
			$wrap.addClass('fps-source-gold');
			$('.fps-pricing-fields .fps-currency-code-row').hide();
			$('.fps-pricing-fields .fps-gold-only-field').show();
			$('.fps-pricing-fields .fps-custom-formula-row').hide();
		}

		updateBaseFieldLabel();
		updateFormulaHint();
		calculatePreview();
	}

	function toggleVariationFields($block) {
		if (!$block || !$block.length) {
			return;
		}
		var $source = $block.find('select[name*="_fps_source_type"], .fps-var-source-type').first();
		var source = $source.val() || 'gold_18k';
		var $currencyRow = $block.find('.fps-currency-code-row');
		var $goldOnly = $block.find('.fps-gold-only-field');
		var $custom = $block.find('.fps-custom-formula-row');
		var $baseRow = $block.find('.fps-base-amount-row');
		var $baseInput = $block.find('.fps-var-base-amount, input[name*="_fps_base_foreign_price"]').first();
		var $profitLabel = $block.find('.fps-profit-field label').first();
		var $hint = $block.find('.fps-var-formula-hint');

		$block.removeClass('fps-source-currency fps-source-gold fps-source-custom');

		if (source === 'currency') {
			$block.addClass('fps-source-currency');
			$currencyRow.show();
			$goldOnly.hide();
			$custom.hide();
			var curr = $block.find('.fps-var-currency-code, select[name*="_fps_currency_code"]').val() || 'usd';
			var currLabel = curr === 'eur' ? 'یورو' : 'دلار';
			$baseRow.find('label').html(i18n('base_price_label', 'قیمت پایه ارزی') + ' (' + currLabel + ')');
			if ($baseInput.length) {
				$baseInput.attr('placeholder', curr === 'eur' ? 'مثلاً 749' : 'مثلاً 700');
			}
			if ($profitLabel.length) {
				$profitLabel.html(i18n('profit_currency', 'درصد سود روی قیمت تبدیل‌شده'));
			}
			if ($hint.length) {
				$hint.text(i18n('formula_currency', ''));
			}
		} else if (source === 'custom_formula') {
			$block.addClass('fps-source-custom');
			$currencyRow.hide();
			$goldOnly.show();
			$custom.show();
			$baseRow.find('label').html(i18n('base_custom_label', 'مقدار پایه / وزن'));
			if ($profitLabel.length) {
				$profitLabel.html(i18n('profit_gold', 'درصد سود فروشنده'));
			}
			if ($hint.length) {
				$hint.text(i18n('formula_custom', ''));
			}
		} else {
			$block.addClass('fps-source-gold');
			$currencyRow.hide();
			$goldOnly.show();
			$custom.hide();
			$baseRow.find('label').html(i18n('weight_label', 'وزن (گرم)'));
			if ($baseInput.length) {
				$baseInput.attr('placeholder', 'مثلاً 10');
			}
			if ($profitLabel.length) {
				$profitLabel.html(i18n('profit_gold', 'درصد سود فروشنده'));
			}
			if ($hint.length) {
				$hint.text(i18n('formula_gold', ''));
			}
		}
	}

	function toggleAllVariations() {
		$('.fps-variation-pricing-fields').each(function () {
			toggleVariationFields($(this));
		});
	}

	function bulkSync() {
		var $btn = $('#fps-bulk-sync-btn');
		var $spin = $('#fps-bulk-spinner');
		var $prog = $('#fps-bulk-progress');
		var $bar = $('#fps-bulk-bar');
		var $status = $('#fps-bulk-status');
		var $result = $('#fps-bulk-result');

		if (!$btn.length || typeof FPS === 'undefined') {
			return;
		}

		$btn.prop('disabled', true);
		$spin.show();
		$prog.show();
		$bar.css('width', '15%');
		$status.text(i18n('calculating', '...'));
		$result.empty();

		$.post(FPS.ajaxUrl, {
			action: 'fps_bulk_sync',
			nonce: FPS.nonce
		})
			.done(function (res) {
				$bar.css('width', '100%');
				if (res && res.success) {
					$status.text(res.data && res.data.message ? res.data.message : 'OK');
					$result.html('<div class="notice notice-success inline"><p>' + (res.data && res.data.message ? res.data.message : 'OK') + '</p></div>');
				} else {
					var msg = (res && res.data && res.data.message) ? res.data.message : i18n('error', 'Error');
					$status.text(msg);
					$result.html('<div class="notice notice-error inline"><p>' + msg + '</p></div>');
				}
			})
			.fail(function () {
				$bar.css('width', '100%');
				$status.text(i18n('error', 'Error'));
			})
			.always(function () {
				$btn.prop('disabled', false);
				$spin.hide();
			});
	}

	function fetchLogs() {
		if (typeof FPS === 'undefined' || !$('#fps-logs-table-body').length) {
			return;
		}
		$.post(FPS.ajaxUrl, {
			action: 'fps_fetch_logs',
			nonce: FPS.nonce
		}).done(function (res) {
			if (res && res.success && res.data && res.data.html) {
				$('#fps-logs-table-body').html(res.data.html);
			}
		});
	}

	$(function () {
		toggleFieldsBySource();
		toggleAllVariations();

		$(document).on(
			'change input',
			'#_fps_source_type, #_fps_currency_code, #_fps_base_foreign_price, #_fps_wage_percent, #_fps_profit_percent, #_fps_tax_percent, #_fps_fixed_fee',
			function () {
				if ($(this).is('#_fps_source_type') || $(this).is('#_fps_currency_code')) {
					toggleFieldsBySource();
				} else {
					calculatePreview();
				}
			}
		);

		$(document).on(
			'change',
			'.fps-variation-pricing-fields select[name*="_fps_source_type"], .fps-variation-pricing-fields select[name*="_fps_currency_code"], .fps-var-source-type, .fps-var-currency-code',
			function () {
				toggleVariationFields($(this).closest('.fps-variation-pricing-fields'));
			}
		);

		$(document).on('woocommerce_variations_loaded woocommerce_variations_added', function () {
			toggleAllVariations();
		});

		$(document).on('click', '#fps-bulk-sync-btn', function (e) {
			e.preventDefault();
			bulkSync();
		});

		$(document).on('click', '#fps-refresh-logs', function (e) {
			e.preventDefault();
			fetchLogs();
		});
	});
})(jQuery);
